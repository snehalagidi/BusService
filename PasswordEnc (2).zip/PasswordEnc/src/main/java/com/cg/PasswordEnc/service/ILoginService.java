package com.cg.PasswordEnc.service;

import java.util.List;

import com.cg.PasswordEnc.model.Login;

public interface ILoginService {

	public List<Login> saveDetails(Login login);
	public String getPassword(String username);
	
}
