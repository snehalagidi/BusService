package com.cg.PasswordEnc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cg.PasswordEnc.model.Login;
import com.cg.PasswordEnc.service.ILoginService;



@RestController
@RequestMapping("/api")
public class LoginController {
	
	@Autowired
	private ILoginService loginservice;
	
	@PostMapping("/msg")
	//
	public ResponseEntity<List<Login>> saveDetails( @RequestBody Login login){
	
		List<Login> logindetails= loginservice.saveDetails(login);
		//loginservice.saveDetails(username, password);
		if(logindetails.isEmpty())

			return new ResponseEntity("Sorry! No Messages",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Login>>(logindetails, HttpStatus.OK); 
		}
	
	@GetMapping("/msg/{username}")
	public ResponseEntity<String> getPassword(@PathVariable("username")String username){
		
		String logindetails= loginservice.getPassword(username);
		
		if(logindetails.isEmpty())

			return new ResponseEntity("Sorry! No Messages",HttpStatus.NOT_FOUND);
		return new ResponseEntity<String>(logindetails, HttpStatus.OK); 
	}
	

}
