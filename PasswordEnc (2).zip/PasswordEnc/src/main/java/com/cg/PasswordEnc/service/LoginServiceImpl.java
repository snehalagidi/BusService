package com.cg.PasswordEnc.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PasswordEnc.model.Login;

import com.cg.PasswordEnc.dao.ILoginDao;

@Service("loginservice")
public class LoginServiceImpl implements ILoginService{

	@Autowired
	private ILoginDao loginDao;
	
	private Base64 base64 = new Base64();
	
	@Override
	public List<Login> saveDetails(Login login) {
		String str="";
		//try {
			//str=getMD5(login.getPassword());
			
			String encodedString = new String(base64.encode(login.getPassword().getBytes()));
		/*} catch (NoSuchAlgorithmException e) {
			
			e.printStackTrace();
		}*/
		login.setPassword(encodedString);
	loginDao.save(login);
		return loginDao.findAll();
	}

	@Override
	public String getPassword(String username) {
		String password=loginDao.getPassword(username);
		String decodedString = new String(base64.decode(password.getBytes()));
		return decodedString;
	}
	
/*	public  String getMD5(String data) throws NoSuchAlgorithmException
    { 
        MessageDigest messageDigest=MessageDigest.getInstance("MD5");

        messageDigest.update(data.getBytes());
        byte[] digest=messageDigest.digest();
        StringBuffer sb = new StringBuffer();
        for (byte b : digest) {
            sb.append(Integer.toHexString((int) (b & 0xff)));
        }
        return sb.toString();
    }
*/
}
