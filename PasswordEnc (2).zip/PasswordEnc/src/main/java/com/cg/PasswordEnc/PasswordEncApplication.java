package com.cg.PasswordEnc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordEncApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordEncApplication.class, args);
	}

}

