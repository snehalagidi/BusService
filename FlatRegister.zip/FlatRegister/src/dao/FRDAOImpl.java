package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import Exception.FRException;
import bean.FO;
import util.DBConnnection;


public class FRDAOImpl implements IFRDAO {
	private static Logger daoLogger=Logger.getLogger(FRDAOImpl.class);

	public Long registerFlat(long flat_seq,int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount)throws FRException{

		try(
				Connection connection=DBConnnection.getConnection();
				PreparedStatement preparedStatement=
						connection.prepareStatement(QM.ADD_FLAT_REGISTRATION_DETAILS);
				Statement statement=connection.createStatement();	
			){
				preparedStatement.setInt(1, flatRegNo);
				preparedStatement.setInt(2, ownerId);
				preparedStatement.setInt(3, flatType);
				preparedStatement.setDouble(4, rentAmount);
				preparedStatement.setDouble(4, depositAmount);
				int n=preparedStatement.executeUpdate();
				if(n>0) {
					daoLogger.info("1 row added to flat registration details table");
					ResultSet resultSet=
							statement.executeQuery(QM.RETRIEVE_FLAT_ID);
					if(resultSet.next()) {
						Integer purchaseId=resultSet.getInt(1);				
						return flat_seq;
					}else {
						return null;
					}
				}else {
					daoLogger.info("Unable to add row to flat registration details");
					//throw new exception("Technical Error. Refer Logs");
				}
			}catch(SQLException e) {
				daoLogger.error(e);
				//throw new exception("Technical Error. Refer Logs");
			}
		return null;
	}

	public List<FO> getAllOwnerIds() throws FRException {
int ownersCount=0;
		
		try(
			Connection connection=DBConnnection.getConnection();	
			Statement statement=connection.createStatement();
		){
			ResultSet resultSet=
					statement.executeQuery(QM.RETRIEVE_ALL_OWNER_DETAILS);
			List<FO> ownersList=new ArrayList<>();
			while(resultSet.next()) {
				ownersCount++;
				FO owners=new FO();
				populateFO(owners,resultSet);
				ownersList.add(owners);
			}
			if(ownersCount!=0) {
				return ownersList;
			}else {
				return null;
			}
		
		}catch(SQLException e) {
			daoLogger.error(e);
			throw new FRException("Technical Error. Refer to Logs");
		}		
	}

	/*private void populateFO(FO mobile, ResultSet resultSet) {
		// TODO Auto-generated method stub
		
	}*/

	private void populateFO(FO owners, ResultSet resultSet) throws SQLException {
		owners.setOwnerId(resultSet.getInt("ownerid"));
		owners.setOwnerName(resultSet.getString("ownername"));
		owners.setMobile(resultSet.getLong("mobile"));

	}

}
