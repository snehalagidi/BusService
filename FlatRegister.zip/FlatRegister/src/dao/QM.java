package dao;

public class QM {
	
	public static final String RETRIEVE_ALL_OWNER_DETAILS="SELECT * FROM flat_owners";
	public static final String ADD_FLAT_REGISTRATION_DETAILS="INSERT INTO flat_registration VALUES(flat_seq.NEXTVAL,?,?,?,?,?,?)";
	public static final String RETRIEVE_FLAT_ID="SELECT flat_seq.CURRVAL from dual";

}
