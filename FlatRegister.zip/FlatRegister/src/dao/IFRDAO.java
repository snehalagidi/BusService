package dao;

import java.util.ArrayList;
import java.util.List;

import Exception.FRException;
import bean.FO;
import bean.FR;

public interface IFRDAO {
	
	public Long registerFlat(long flat_seq,int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount)
	throws FRException;
	public List<FO> getAllOwnerIds()throws FRException;
}
