package Exception;

public class FRException extends Exception{
	
	String message;

	public FRException() {
		super();
	}

	public FRException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "FlatRegistrationException message=" + message;
	}
}
