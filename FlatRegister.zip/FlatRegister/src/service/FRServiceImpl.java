package service;

import java.util.List;

import Exception.FRException;
import bean.FO;
import dao.FRDAOImpl;
import dao.IFRDAO;

public class FRServiceImpl implements IFRService{
	private IFRDAO frdao=new FRDAOImpl();

	@Override
	public Long registerFlat(long flat_seq, int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount,
			double depositAmount) throws FRException {
		return frdao.registerFlat(flat_seq, flatRegNo, ownerId, flatType, flatArea, rentAmount, depositAmount);
	}

	@Override
	public List<FO> getAllOwnerIds() throws FRException {
		return frdao.getAllOwnerIds();
	}

}
