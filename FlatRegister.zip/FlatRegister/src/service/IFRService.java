package service;

import java.util.List;

import Exception.FRException;
import bean.FO;

public interface IFRService {
	
	public abstract Long registerFlat(long flat_seq,int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount)throws FRException;
	public abstract List<FO> getAllOwnerIds()throws FRException;
	
}
