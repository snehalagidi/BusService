package bean;

public class FR {
	
	private long flat_seq;
	private int FlatRegNo;
	private int OwnerId;
	private int FlatType;
	private int FlatArea;
	private double RentAmount;
	private double DepositAmount;
	
	public FR() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FR(int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount) {
		super();
		FlatRegNo = flatRegNo;
		OwnerId = ownerId;
		FlatType = flatType;
		FlatArea = flatArea;
		RentAmount = rentAmount;
		DepositAmount = depositAmount;
	}
	
	public long getFlat_seq() {
		return flat_seq;
	}

	public void setFlat_seq(long flat_seq) {
		this.flat_seq = flat_seq;
	}

	public int getFlatRegNo() {
		return FlatRegNo;
	}

	public void setFlatRegNo(int flatRegNo) {
		FlatRegNo = flatRegNo;
	}

	public int getOwnerId() {
		return OwnerId;
	}

	public void setOwnerId(int ownerId) {
		OwnerId = ownerId;
	}

	public int getFlatType() {
		return FlatType;
	}

	public void setFlatType(int flatType) {
		FlatType = flatType;
	}

	public int getFlatArea() {
		return FlatArea;
	}

	public void setFlatArea(int flatArea) {
		FlatArea = flatArea;
	}

	public double getRentAmount() {
		return RentAmount;
	}

	public void setRentAmount(double rentAmount) {
		RentAmount = rentAmount;
	}

	public double getDepositAmount() {
		return DepositAmount;
	}

	public void setDepositAmount(double depositAmount) {
		DepositAmount = depositAmount;
	}

	@Override
	public String toString() {
		return "FR [FlatRegNo=" + FlatRegNo + ", OwnerId=" + OwnerId + ", FlatType=" + FlatType + ", FlatArea="
				+ FlatArea + ", RentAmount=" + RentAmount + ", DepositAmount=" + DepositAmount + "]";
	}
	
	
	
}
