package bean;

public class FO {
	
	private static int OwnerId;
	private static String OwnerName;
	private static long Mobile;
	
	public FO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FO(int ownerId, String ownerName, long mobile) {
		super();
		OwnerId = ownerId;
		OwnerName = ownerName;
		Mobile = mobile;
	}
	public int getOwnerId() {
		return OwnerId;
	}
	public void setOwnerId(int ownerId) {
		OwnerId = ownerId;
	}
	public String getOwnerName() {
		return OwnerName;
	}
	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
	public long getMobile() {
		return Mobile;
	}
	public void setMobile(long mobile) {
		Mobile = mobile;
	}
	@Override
	public String toString() {
		return "FO [OwnerId=" + OwnerId + ", OwnerName=" + OwnerName + ", Mobile=" + Mobile + "]";
	}
	
	
}
