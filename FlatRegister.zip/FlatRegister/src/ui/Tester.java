package ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import Exception.FRException;
import bean.FO;
import bean.FR;
import dao.FRDAOImpl;
import dao.IFRDAO;
import service.FRServiceImpl;
import service.IFRService;

public class Tester {

	private static Scanner scanner=new Scanner(System.in);
	private static IFRService frservice=new FRServiceImpl();
	private static IFRDAO frdao=new FRDAOImpl();
	
	private static Logger myUILogger=Logger.getLogger(Tester.class);
	
	public static void main(String[] args) throws FRException {		
		PropertyConfigurator.configure("resources/log4j.properties");
		//FRServiceImpl
		while (true) {
			// show menu
			System.out.println("   Flat Registration Service ");
			System.out.println("_______________________________\n");

			System.out.println("1.Flat Register ");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			
			try {
				int option = scanner.nextInt();
				switch (option) {
				case 1: 		  
					 
					  System.out.println("Existing owner ids are"+frservice.getAllOwnerIds());
					  System.out.println("Please enter your owner Id from above list ");
					  Long OwnerId=scanner.nextLong();
					  scanner.nextLine();//clears KBD buffer
					  System.out.println("Select Flat Type(1-1BHK,2-2BHK):");
					  String FlatType=scanner.nextLine();	
					  scanner.nextLine();//clears KBD buffer
					  System.out.println("Enter Flat area in sq. ft.: ");
					  String FlatArea= scanner.nextLine();					  
					  System.out.println("Enter desired rent amount Rs:");
					  String RentAmount=scanner.nextLine();	
					  scanner.nextLine();
					  System.out.println("Enter desired deposit amount RS:");
					  String DepositAmount=scanner.nextLine();	
					  scanner.nextLine();
					  
					  
					  
				case 2:
					System.exit(0);
					break;
				
				}
			}catch (InputMismatchException e) {
				e.printStackTrace();
			
				myUILogger.warn("Enter only integer values[1-6]");
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
		}
	}
		public Long registerFlat(long flat_seq, int flatRegNo, int ownerId, int flatType, int flatArea, double rentAmount,double depositAmount) {
				Long flatId=null;
				try {
					flatId= 
							frservice.registerFlat(flat_seq,flatRegNo,ownerId,flatType,flatArea,rentAmount,depositAmount);
					System.out.println("Purchase Id: "+flatId);
					return flatId;
				}catch(FRException e) {
					myUILogger.error(e.getMessage());
					System.out.println(e.getMessage());
				}
				return flatId;
		}
		
		public List<FO> getAllOwnerIds(){
			List<FO> mobileList;
			try {
				mobileList = frservice.getAllOwnerIds();
				return mobileList; 
			} catch (FRException e) {	
				myUILogger.error(e.getMessage());
				//log to file
				System.out.println(e.getMessage());
			}
			return null;
	
		}
}

