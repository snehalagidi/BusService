package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Model.ProductBean;
import com.capg.dao.IProductDao;
import com.capg.service.IProductService;

import ch.qos.logback.core.net.SyslogOutputStream;

@RestController
@RequestMapping("/api")
public class ProductController {

	@Autowired
	private IProductService productService;
	
	@Autowired
	private IProductDao productDao;
	
	@PostMapping("/products")
		public ResponseEntity<List<ProductBean>> saveProduct(@RequestBody ProductBean product){
			List<ProductBean> products=productService.saveProduct(product);
			if(products.isEmpty()) {
				return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<ProductBean>>(products, HttpStatus.OK);
			
		}
		
		@GetMapping("/products")
		public ResponseEntity<List<ProductBean>> getProduct(){
			List<ProductBean> products=productService.getAllProducts();
			if(products.isEmpty()) {
				return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<ProductBean>>(products, HttpStatus.OK);
			
		}
		
		
		@DeleteMapping("/products/{productId}")
		public ResponseEntity<List<ProductBean>> deleteProduct(
				@PathVariable("productId")Integer productId){
			List<ProductBean> products= productService.deleteProduct(productId);
			if(products.isEmpty() || products==null) {
				return new ResponseEntity("Sorry! ProductsId not available!", 
						HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<List<ProductBean>>(products, HttpStatus.OK);
		}
		
		
		@PutMapping("/products")
		public ResponseEntity<List<ProductBean>> updateProduct(
				@RequestBody ProductBean product){
			List<ProductBean> products= productService.updateProduct(product);
			if(products.isEmpty())
			{
				return new ResponseEntity("Sorry! Products not available!", 
						HttpStatus.NOT_FOUND);
			}
			
			return new ResponseEntity<List<ProductBean>>(products, HttpStatus.OK);
		}
		 
	 @GetMapping("/products/{input}")
	 public ResponseEntity<List<ProductBean>> findProduct(@PathVariable("input") String input){
			List<ProductBean> products=productDao.findProduct(input);
			/*System.out.println(products);*/
			if(products.isEmpty()) {
				return new ResponseEntity("Sorry No Products Found..",HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<List<ProductBean>>(products, HttpStatus.OK);
			
		}

}
