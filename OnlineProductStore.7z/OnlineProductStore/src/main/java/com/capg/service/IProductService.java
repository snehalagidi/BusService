package com.capg.service;

import java.util.List;

import com.capg.Model.ProductBean;

public interface IProductService {

	public List<ProductBean> saveProduct(ProductBean product);
	public List<ProductBean> getAllProducts();
	public List<ProductBean> deleteProduct(Integer productId);
	public List<ProductBean> updateProduct(ProductBean product); 
 

}
